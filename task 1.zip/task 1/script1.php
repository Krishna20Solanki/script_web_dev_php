<?php
	echo "Hello, World!"
?>