<?php
	$Name='Krishna';
	$Age=21;
		echo "My Name is $Name and I am $Age Years Old.";
?>