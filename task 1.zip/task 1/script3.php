<?php
	$Num1=50;
	$Num2=50;
		echo $Num1+$Num2;
?>