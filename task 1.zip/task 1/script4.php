<?php
	$A="Hello ";
	$B=" php";
		echo $A . $B;
?>