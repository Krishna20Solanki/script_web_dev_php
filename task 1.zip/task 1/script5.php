<?php
	$pi=3.14159;
		echo $pi;
?>