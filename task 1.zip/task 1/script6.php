<?php
	$Num=13;
	If($Num%2==0) 
	{
		echo "$Num is even numbber";
	}
	Else
	{
		echo "$Num is odd number";
	}	
?>