<?php
	echo "\n The Number Before swapping\n";
$x=9;
$y=7;
	echo " x=$x ";
	echo " y=$y ";
	echo "<br>The Number After swapping\n";
$temp=$x;
$x=$y;
$y=$temp;
echo " X=$x ";
echo " y=$y ";
?>