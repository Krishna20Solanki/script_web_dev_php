<?php
	$text="krishna";
echo strlen("$text");	
?>