<?php
$date=13;
$month=06;
$year=2002;
echo "".$date."/". $month ."/". $year;
?>